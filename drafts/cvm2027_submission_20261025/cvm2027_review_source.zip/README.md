# CVM 2027 anonymous review sources

Status: revision review draft; author approval is pending.

Build with TeX Live from this directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The source uses the official unchanged CVM review style, 10-point Times,
two columns, US Letter paper, review line rulers, and numbered pages.
It contains 51 cited references and three displayed figures. The two figure
layout files use viewports of unchanged original figure assets.

Replace the official **** placeholder only with the actual portal paper ID.
